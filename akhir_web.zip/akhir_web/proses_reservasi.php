<?php
session_start();

include 'koneksi.php';

$nama_rs = "";
$nama_poli = "";
$nama_dokter = "";
$tanggal_reservasi = "";
$no_antrian_baru = "";
$nama_pasien = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $dbrs_id = $_POST['dbrs_id'];
    $poli_id = $_POST['poli_id'];
    $dokter_id = $_POST['dokter_id'];
    $tanggal_reservasi = $_POST['tanggal_reservasi'];

       // Ambil nomor antrian terakhir untuk dokter dan poli yang dipilih
       $antrian_sql = "SELECT MAX(no_antrian) AS no_antrian_terakhir 
       FROM reservasi 
       WHERE dbrs_id = '$dbrs_id' 
       AND poli_id = '$poli_id' 
       AND dokter_id = '$dokter_id' 
       AND tanggal_reservasi = '$tanggal_reservasi'";
$antrian_result = mysqli_query($conn, $antrian_sql);
$antrian_row = mysqli_fetch_assoc($antrian_result);
$no_antrian_terakhir = $antrian_row['no_antrian_terakhir'];

// Tambahkan nomor antrian baru
$no_antrian_baru = $no_antrian_terakhir ? $no_antrian_terakhir + 1 : 1;

// Simpan data reservasi
$sql = "INSERT INTO reservasi (dbrs_id, poli_id, dokter_id, tanggal_reservasi, no_antrian) 
VALUES ('$dbrs_id', '$poli_id', '$dokter_id', '$tanggal_reservasi', '$no_antrian_baru')";
if (mysqli_query($conn, $sql)) {
$message = "Reservasi berhasil! Nomor antrian Anda adalah $no_antrian_baru";

// Ambil informasi tambahan untuk ditampilkan
$dbrs_sql = "SELECT nama FROM dbrs WHERE id = '$dbrs_id'";
$dbrs_result = mysqli_query($conn, $dbrs_sql);
$dbrs_row = mysqli_fetch_assoc($dbrs_result);
$nama_rs = $dbrs_row['nama'];

$poli_sql = "SELECT name FROM poli WHERE id = '$poli_id'";
$poli_result = mysqli_query($conn, $poli_sql);
$poli_row = mysqli_fetch_assoc($poli_result);
$name_poli = $poli_row['name'];

$dokter_sql = "SELECT nama FROM db_dokter WHERE id = '$dokter_id'";
$dokter_result = mysqli_query($conn, $dokter_sql);
$dokter_row = mysqli_fetch_assoc($dokter_result);
$nama_dokter = $dokter_row['nama'];

// Simpan nama pasien dari sesi atau database sesuai dengan logika aplikasi
// Contoh: $nama_pasien = $_SESSION['nama_pasien'];
} else {
$message = "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Hasil Reservasi</title>
<link rel="stylesheet" type="text/css" href="proses_reservasi.css" />
</head>
<body>
<div class="container">
<h2>Hasil Reservasi</h2>
<?php if (isset($message)): ?>
<div class="card">
   <p><strong>Pesan:</strong> <?php echo $message; ?></p>
   <p><strong>Nama Rumah Sakit:</strong> <?php echo $nama_rs; ?></p>
   <p><strong>Poli:</strong> <?php echo $nama_poli; ?></p>
   <p><strong>Dokter:</strong> <?php echo $nama_dokter; ?></p>
   <p><strong>Tanggal Reservasi:</strong> <?php echo $tanggal_reservasi; ?></p>
   <p><strong>Nomor Antrian:</strong> <?php echo $no_antrian_baru; ?></p>
</div>
<?php endif; ?>
<div class="button-container">
<button type="button" class="cancel-button" onclick="window.location.href='reservasi.php'">Kembali ke Reservasi</button>
</div>
</div>
</body>
</html>
